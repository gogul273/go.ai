# GO AI — Godel Labs Workspace

Classical + Quantum AI in one app.

## 🚀 Deploy to Vercel in 3 Steps

### Step 1 — Push to GitHub
1. Go to github.com → New Repository → name it `go-ai`
2. Run these commands:
```bash
git init
git add .
git commit -m "GO AI initial deploy"
git remote add origin https://github.com/YOUR_USERNAME/go-ai.git
git push -u origin main
```

### Step 2 — Connect to Vercel
1. Go to vercel.com → Sign up with GitHub
2. Click "New Project"
3. Import your `go-ai` repository
4. Click **Deploy** ✅

### Step 3 — Your Live URL
```
https://go-ai.vercel.app
```

## 🖥️ Run Locally
```bash
npm install
npm start
```
Open http://localhost:3000

## 📱 Open on Mobile (same WiFi)
1. Run `npm start`
2. Find your PC IP: run `ipconfig` (Windows) or `ifconfig` (Mac)
3. Open `http://YOUR_IP:3000` on your phone
