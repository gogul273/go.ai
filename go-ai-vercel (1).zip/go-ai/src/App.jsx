import { useState, useRef, useEffect } from "react";

// ===================== SPLASH SCREEN =====================
function SplashScreen({ onStart }) {
  const [visible, setVisible] = useState(false);
  const [btnHover, setBtnHover] = useState(false);
  const [launching, setLaunching] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  function handleStart() {
    setLaunching(true);
    setTimeout(onStart, 900);
  }

  return (
    <div style={{
      position: "fixed", inset: 0,
      background: "#04080f",
      display: "flex", alignItems: "center", justifyContent: "center",
      flexDirection: "column", gap: 0,
      opacity: launching ? 0 : 1,
      transition: "opacity 0.8s ease",
      overflow: "hidden"
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=Inter:wght@300;400&display=swap');
        @keyframes ambientPulse {
          0%, 100% { opacity: 0.6; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.05); }
        }
        @keyframes logoReveal {
          0% { opacity: 0; transform: scale(0.85) translateY(20px); filter: blur(20px); }
          100% { opacity: 1; transform: scale(1) translateY(0); filter: blur(0); }
        }
        @keyframes subtitleReveal {
          0% { opacity: 0; transform: translateY(10px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        @keyframes btnReveal {
          0% { opacity: 0; transform: translateY(16px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        @keyframes particleDrift {
          0% { transform: translateY(0) translateX(0); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 0.6; }
          100% { transform: translateY(-80vh) translateX(30px); opacity: 0; }
        }
        @keyframes glowPulse {
          0%, 100% { text-shadow: 0 0 30px rgba(255,255,255,0.8), 0 0 60px rgba(100,180,255,0.4), 0 0 100px rgba(60,140,255,0.2); }
          50% { text-shadow: 0 0 40px rgba(255,255,255,1), 0 0 80px rgba(100,180,255,0.7), 0 0 130px rgba(60,140,255,0.4); }
        }
        @keyframes borderGlow {
          0%, 100% { box-shadow: 0 0 20px rgba(59,130,246,0.5), inset 0 0 20px rgba(59,130,246,0.1); }
          50% { box-shadow: 0 0 35px rgba(59,130,246,0.8), inset 0 0 30px rgba(59,130,246,0.2); }
        }
        @keyframes scanDown {
          0% { top: -2px; opacity: 0.6; }
          100% { top: 100%; opacity: 0; }
        }
        @keyframes cornerBlink {
          0%, 80%, 100% { opacity: 0.3; }
          40% { opacity: 1; }
        }
      `}</style>

      {/* Ambient blue glow — top left */}
      <div style={{
        position: "absolute", top: -150, left: -150,
        width: 600, height: 600,
        background: "radial-gradient(circle, rgba(29,78,160,0.25) 0%, transparent 65%)",
        animation: "ambientPulse 6s ease-in-out infinite",
        pointerEvents: "none"
      }} />
      {/* Ambient blue glow — bottom right */}
      <div style={{
        position: "absolute", bottom: -150, right: -150,
        width: 500, height: 500,
        background: "radial-gradient(circle, rgba(29,78,160,0.18) 0%, transparent 65%)",
        animation: "ambientPulse 8s ease-in-out infinite reverse",
        pointerEvents: "none"
      }} />

      {/* Floating particles */}
      {[...Array(18)].map((_, i) => (
        <div key={i} style={{
          position: "absolute",
          left: `${5 + (i * 5.5) % 90}%`,
          bottom: `${(i * 17) % 30}%`,
          width: i % 3 === 0 ? 2 : 1,
          height: i % 3 === 0 ? 2 : 1,
          borderRadius: "50%",
          background: i % 4 === 0 ? "#3b82f6" : "rgba(255,255,255,0.4)",
          animation: `particleDrift ${8 + (i % 7)}s ${i * 0.4}s linear infinite`,
          pointerEvents: "none"
        }} />
      ))}

      {/* Corner decorations */}
      {[
        { top: 24, left: 24, borderTop: "1px solid", borderLeft: "1px solid" },
        { top: 24, right: 24, borderTop: "1px solid", borderRight: "1px solid" },
        { bottom: 24, left: 24, borderBottom: "1px solid", borderLeft: "1px solid" },
        { bottom: 24, right: 24, borderBottom: "1px solid", borderRight: "1px solid" },
      ].map((s, i) => (
        <div key={i} style={{
          position: "absolute", ...s,
          width: 24, height: 24,
          borderColor: "rgba(59,130,246,0.4)",
          animation: `cornerBlink ${2 + i * 0.5}s ease-in-out infinite`,
          pointerEvents: "none"
        }} />
      ))}

      {/* Logo */}
      <div style={{
        opacity: visible ? 1 : 0,
        animation: visible ? "logoReveal 1s cubic-bezier(0.16,1,0.3,1) forwards" : "none",
        marginBottom: 24,
        position: "relative"
      }}>
        <div style={{
          fontFamily: "'Orbitron', monospace",
          fontSize: "clamp(72px, 12vw, 110px)",
          fontWeight: 900,
          color: "#ffffff",
          letterSpacing: "0.12em",
          animation: "glowPulse 3s ease-in-out infinite",
          userSelect: "none",
          lineHeight: 1
        }}>
          GO&nbsp;&nbsp;AI
        </div>
        {/* Scan line on logo */}
        <div style={{
          position: "absolute", left: 0, right: 0, height: 2,
          background: "linear-gradient(90deg, transparent, rgba(100,180,255,0.6), transparent)",
          animation: "scanDown 3s ease-in-out infinite",
          pointerEvents: "none"
        }} />
      </div>

      {/* Subtitle */}
      <div style={{
        opacity: visible ? 1 : 0,
        animation: visible ? "subtitleReveal 1s 0.4s cubic-bezier(0.16,1,0.3,1) both" : "none",
        fontFamily: "'Inter', sans-serif",
        fontWeight: 300,
        fontSize: "clamp(13px, 2vw, 17px)",
        color: "rgba(160,190,230,0.75)",
        letterSpacing: "0.08em",
        marginBottom: 56,
        textAlign: "center"
      }}>
        Classical + Quantum AI in one chat
      </div>

      {/* Start button */}
      <div style={{
        opacity: visible ? 1 : 0,
        animation: visible ? "btnReveal 1s 0.7s cubic-bezier(0.16,1,0.3,1) both" : "none",
      }}>
        <button
          onClick={handleStart}
          onMouseEnter={() => setBtnHover(true)}
          onMouseLeave={() => setBtnHover(false)}
          style={{
            background: btnHover
              ? "linear-gradient(135deg, #2563eb, #3b82f6)"
              : "linear-gradient(135deg, #1d4ed8, #2563eb)",
            border: "none",
            borderRadius: 50,
            padding: "18px 52px",
            color: "#fff",
            fontFamily: "'Inter', sans-serif",
            fontWeight: 600,
            fontSize: 18,
            letterSpacing: "0.04em",
            cursor: "pointer",
            display: "flex", alignItems: "center", gap: 12,
            animation: "borderGlow 2.5s ease-in-out infinite",
            transition: "transform 0.2s, background 0.2s",
            transform: btnHover ? "scale(1.04) translateY(-1px)" : "scale(1)",
          }}
        >
          Start
          <span style={{
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            width: 28, height: 28, borderRadius: "50%",
            background: "rgba(255,255,255,0.18)",
            fontSize: 15,
            transition: "transform 0.2s",
            transform: btnHover ? "translateX(3px)" : "translateX(0)"
          }}>→</span>
        </button>
      </div>

      {/* Bottom version tag */}
      <div style={{
        position: "absolute", bottom: 28,
        fontFamily: "monospace", fontSize: 10,
        color: "rgba(59,130,246,0.35)", letterSpacing: 3
      }}>
        v2.1.0 · CLASSICAL + QUANTUM
      </div>
    </div>
  );
}

// ===================== WORKSPACE (same as before, refined) =====================
const MODULES = [
  { id: "chat",    label: "CHAT",   icon: "◈" },
  { id: "search",  label: "SEARCH", icon: "⌕" },
  { id: "engine",  label: "ENGINE", icon: "⬡" },
  { id: "dashboard", label: "DASH", icon: "◉" },
  { id: "tools",   label: "TOOLS",  icon: "◎" },
];

const TOOLS = [
  { id: "base64", label: "Base64" },
  { id: "hash", label: "Hash" },
  { id: "json", label: "JSON" },
  { id: "regex", label: "Regex" },
];

const STATS = [
  { label: "UPTIME", value: "99.97%", trend: "↑", color: "#3b82f6" },
  { label: "QUERIES", value: "2,847", trend: "↑", color: "#3b82f6" },
  { label: "LATENCY", value: "142ms", trend: "↓", color: "#60a5fa" },
  { label: "TOKENS", value: "1.2M", trend: "↑", color: "#3b82f6" },
];

function useTypewriter(text, speed = 16) {
  const [displayed, setDisplayed] = useState("");
  useEffect(() => {
    setDisplayed("");
    let i = 0;
    const iv = setInterval(() => {
      setDisplayed(text.slice(0, i + 1));
      i++;
      if (i >= text.length) clearInterval(iv);
    }, speed);
    return () => clearInterval(iv);
  }, [text]);
  return displayed;
}

function ChatMsg({ msg }) {
  const isUser = msg.role === "user";
  const displayed = useTypewriter(isUser ? msg.content : msg.content, isUser ? 0 : 16);
  return (
    <div style={{ display: "flex", gap: 10, marginBottom: 14, flexDirection: isUser ? "row-reverse" : "row", alignItems: "flex-start" }}>
      <div style={{
        width: 30, height: 30, borderRadius: 6, flexShrink: 0,
        background: isUser ? "#1d4ed8" : "#0f172a",
        border: `1px solid ${isUser ? "#3b82f6" : "#1e3a5f"}`,
        display: "flex", alignItems: "center", justifyContent: "center",
        fontFamily: "'Orbitron', monospace", fontWeight: 700,
        color: isUser ? "#fff" : "#60a5fa", fontSize: 9,
        boxShadow: isUser ? "0 0 12px rgba(59,130,246,0.4)" : "0 0 8px rgba(30,58,95,0.5)"
      }}>
        {isUser ? "YOU" : "AI"}
      </div>
      <div style={{
        maxWidth: "78%",
        background: isUser ? "rgba(29,78,216,0.12)" : "rgba(15,23,42,0.8)",
        border: `1px solid ${isUser ? "rgba(59,130,246,0.3)" : "rgba(30,58,95,0.6)"}`,
        borderRadius: isUser ? "12px 4px 12px 12px" : "4px 12px 12px 12px",
        padding: "10px 14px",
        fontFamily: "'Inter', sans-serif", fontSize: 13,
        color: isUser ? "#bfdbfe" : "#cbd5e1", lineHeight: 1.7,
        whiteSpace: "pre-wrap",
      }}>
        {isUser ? msg.content : displayed}
        {!isUser && displayed.length < msg.content.length && (
          <span style={{ animation: "blink 0.7s infinite", color: "#3b82f6" }}>█</span>
        )}
      </div>
    </div>
  );
}

function ChatPanel() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "GO AI online. Classical + Quantum processing ready.\n\nHow can I assist you today?" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  async function send() {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    const next = [...messages, { role: "user", content: text }];
    setMessages(next);
    setLoading(true);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: "You are GO AI — a hybrid Classical + Quantum AI assistant. Be helpful, clear, and technically precise. Use code blocks when relevant.",
          messages: next.map(m => ({ role: m.role, content: m.content }))
        })
      });
      const data = await res.json();
      const reply = data.content?.map(b => b.text || "").join("") || "No response.";
      setMessages([...next, { role: "assistant", content: reply }]);
    } catch {
      setMessages([...next, { role: "assistant", content: "Connection error. Please retry." }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ flex: 1, overflowY: "auto", padding: "16px 14px", scrollbarWidth: "thin", scrollbarColor: "#1e3a5f #04080f" }}>
        {messages.map((m, i) => <ChatMsg key={i} msg={m} />)}
        {loading && (
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <div style={{ width: 30, height: 30, borderRadius: 6, background: "#0f172a", border: "1px solid #1e3a5f", display: "flex", alignItems: "center", justifyContent: "center", color: "#60a5fa", fontSize: 9, fontFamily: "monospace" }}>AI</div>
            <div style={{ fontFamily: "monospace", color: "#3b82f6", fontSize: 13 }}>
              <span style={{ animation: "blink 1s infinite" }}>Thinking</span>
              <span>...</span>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      <div style={{ padding: "10px 14px", borderTop: "1px solid rgba(30,58,95,0.8)", display: "flex", gap: 8, background: "rgba(4,8,15,0.6)" }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && send()}
          placeholder="Ask anything..."
          style={{
            flex: 1, background: "rgba(15,23,42,0.8)", border: "1px solid rgba(30,58,95,0.8)",
            borderRadius: 8, padding: "11px 14px", color: "#e2e8f0",
            fontFamily: "'Inter', sans-serif", fontSize: 13, outline: "none",
          }}
        />
        <button onClick={send} disabled={loading || !input.trim()} style={{
          background: "linear-gradient(135deg, #1d4ed8, #2563eb)",
          border: "none", borderRadius: 8,
          color: "#fff", fontFamily: "monospace", fontSize: 12,
          padding: "0 18px", cursor: loading ? "not-allowed" : "pointer",
          opacity: loading || !input.trim() ? 0.5 : 1,
          letterSpacing: 1, transition: "opacity 0.2s"
        }}>SEND</button>
      </div>
    </div>
  );
}

function DashboardPanel() {
  const [bars, setBars] = useState([40, 65, 30, 80, 55, 70, 45]);
  const [logs, setLogs] = useState([
    { t: "00:00:01", msg: "GO AI system boot complete", ok: true },
    { t: "00:00:02", msg: "Quantum engine initialized", ok: true },
    { t: "00:00:03", msg: "Classical core synchronized", ok: true },
    { t: "00:00:04", msg: "Awaiting operator input...", ok: false },
  ]);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const iv = setInterval(() => {
      setTime(new Date());
      setBars(b => b.map(() => Math.floor(Math.random() * 75 + 20)));
      const now = new Date();
      const ts = `${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}:${String(now.getSeconds()).padStart(2,"0")}`;
      const events = ["Quantum coherence: stable", "Classical bridge OK", "Neural sync active", "Data stream healthy", "Memory GC complete"];
      setLogs(l => [...l.slice(-7), { t: ts, msg: events[Math.floor(Math.random() * events.length)], ok: true }]);
    }, 2200);
    return () => clearInterval(iv);
  }, []);

  return (
    <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 14, height: "100%", overflowY: "auto" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {STATS.map(s => (
          <div key={s.label} style={{
            background: "rgba(15,23,42,0.8)", border: "1px solid rgba(30,58,95,0.7)",
            borderRadius: 8, padding: "12px 16px"
          }}>
            <div style={{ color: "#475569", fontFamily: "monospace", fontSize: 10, letterSpacing: 2, marginBottom: 6 }}>{s.label}</div>
            <div style={{ display: "flex", alignItems: "baseline", gap: 6 }}>
              <span style={{ color: "#e2e8f0", fontFamily: "'Orbitron', monospace", fontSize: 20, fontWeight: 700 }}>{s.value}</span>
              <span style={{ color: s.trend === "↑" ? "#3b82f6" : "#f87171", fontSize: 16 }}>{s.trend}</span>
            </div>
          </div>
        ))}
      </div>

      <div style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(30,58,95,0.7)", borderRadius: 8, padding: 14 }}>
        <div style={{ color: "#475569", fontFamily: "monospace", fontSize: 10, letterSpacing: 2, marginBottom: 12 }}>ACTIVITY MONITOR</div>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 5, height: 64 }}>
          {bars.map((h, i) => (
            <div key={i} style={{ flex: 1, height: "100%", display: "flex", alignItems: "flex-end" }}>
              <div style={{
                width: "100%", height: `${h}%`,
                background: `linear-gradient(to top, #1d4ed8, #60a5fa)`,
                borderRadius: "3px 3px 0 0",
                transition: "height 1s cubic-bezier(0.4,0,0.2,1)",
                boxShadow: "0 0 8px rgba(59,130,246,0.35)"
              }} />
            </div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 5, marginTop: 6 }}>
          {["M","T","W","T","F","S","S"].map((d,i) => (
            <div key={i} style={{ flex: 1, textAlign: "center", color: "#334155", fontFamily: "monospace", fontSize: 9 }}>{d}</div>
          ))}
        </div>
      </div>

      <div style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(30,58,95,0.7)", borderRadius: 8, padding: 14, flex: 1 }}>
        <div style={{ color: "#475569", fontFamily: "monospace", fontSize: 10, letterSpacing: 2, marginBottom: 10 }}>SYSTEM LOG</div>
        {logs.map((l, i) => (
          <div key={i} style={{ display: "flex", gap: 10, fontFamily: "monospace", fontSize: 11, marginBottom: 5 }}>
            <span style={{ color: "#334155" }}>{l.t}</span>
            <span style={{ color: l.ok ? "#1d4ed8" : "#475569" }}>●</span>
            <span style={{ color: l.ok ? "#94a3b8" : "#475569" }}>{l.msg}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ToolsPanel() {
  const [activeTool, setActiveTool] = useState("base64");
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [mode, setMode] = useState("encode");

  function run() {
    try {
      if (activeTool === "base64") {
        setOutput(mode === "encode" ? btoa(unescape(encodeURIComponent(input))) : decodeURIComponent(escape(atob(input))));
      } else if (activeTool === "hash") {
        let h = 5381;
        for (let i = 0; i < input.length; i++) h = ((h << 5) + h) ^ input.charCodeAt(i);
        const hex = (h >>> 0).toString(16).padStart(8, "0");
        setOutput(`djb2:  ${hex.repeat(8)}\nfnv1:  ${hex.split("").reverse().join("").repeat(4)}\nlen:   ${input.length} chars | ${new Blob([input]).size} bytes`);
      } else if (activeTool === "json") {
        setOutput(JSON.stringify(JSON.parse(input), null, 2));
      } else if (activeTool === "regex") {
        const lines = input.split("\n");
        const pattern = lines[0] || "";
        const flags = lines[1] || "g";
        const testStr = lines.slice(2).join("\n");
        const re = new RegExp(pattern, flags);
        const matches = [...testStr.matchAll(re)];
        setOutput(matches.length ? matches.map(m => `Match: "${m[0]}"  index: ${m.index}${m.groups ? `  groups: ${JSON.stringify(m.groups)}` : ""}`).join("\n") : "No matches found.");
      }
    } catch(e) {
      setOutput(`ERROR: ${e.message}`);
    }
  }

  const placeholders = {
    base64: "Enter text to encode or decode...",
    hash: "Enter text to hash...",
    json: '{\n  "key": "value",\n  "num": 42\n}',
    regex: "pattern\nflags\ntest string here"
  };

  return (
    <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 12, height: "100%" }}>
      <div style={{ display: "flex", gap: 6 }}>
        {TOOLS.map(t => (
          <button key={t.id} onClick={() => { setActiveTool(t.id); setInput(""); setOutput(""); }} style={{
            background: activeTool === t.id ? "rgba(29,78,216,0.25)" : "rgba(15,23,42,0.6)",
            border: `1px solid ${activeTool === t.id ? "rgba(59,130,246,0.6)" : "rgba(30,58,95,0.5)"}`,
            borderRadius: 6, color: activeTool === t.id ? "#60a5fa" : "#475569",
            fontFamily: "monospace", fontSize: 11, padding: "6px 14px", cursor: "pointer",
            transition: "all 0.2s", letterSpacing: 1
          }}>{t.label}</button>
        ))}
      </div>

      {activeTool === "base64" && (
        <div style={{ display: "flex", gap: 6 }}>
          {["encode","decode"].map(m => (
            <button key={m} onClick={() => setMode(m)} style={{
              background: mode === m ? "rgba(29,78,216,0.15)" : "transparent",
              border: `1px solid ${mode === m ? "rgba(59,130,246,0.4)" : "rgba(30,58,95,0.4)"}`,
              borderRadius: 5, color: mode === m ? "#93c5fd" : "#475569",
              fontFamily: "monospace", fontSize: 11, padding: "4px 12px", cursor: "pointer"
            }}>{m}</button>
          ))}
        </div>
      )}

      <textarea value={input} onChange={e => setInput(e.target.value)}
        placeholder={placeholders[activeTool]} rows={5}
        style={{
          background: "rgba(15,23,42,0.8)", border: "1px solid rgba(30,58,95,0.7)",
          borderRadius: 8, color: "#cbd5e1", fontFamily: "'Courier New', monospace",
          fontSize: 12, padding: 12, resize: "vertical", outline: "none", lineHeight: 1.6
        }}
      />

      <button onClick={run} style={{
        background: "linear-gradient(135deg, #1d4ed8, #2563eb)",
        border: "none", borderRadius: 8, color: "#fff",
        fontFamily: "monospace", fontSize: 12, padding: "11px 0",
        cursor: "pointer", letterSpacing: 2
      }}>▶  EXECUTE</button>

      {output && (
        <div style={{
          flex: 1, background: "rgba(4,8,15,0.9)", border: "1px solid rgba(30,58,95,0.7)",
          borderRadius: 8, padding: 14, fontFamily: "'Courier New', monospace", fontSize: 12,
          color: "#60a5fa", whiteSpace: "pre-wrap", overflowY: "auto", lineHeight: 1.7
        }}>
          <div style={{ color: "#334155", fontSize: 10, letterSpacing: 2, marginBottom: 8 }}>OUTPUT</div>
          {output}
        </div>
      )}
    </div>
  );
}

// ===================== SEARCH PANEL =====================
const ENGINES = [
  { id: "all",       label: "All",        icon: "⌕",  color: "#60a5fa" },
  { id: "google",    label: "Google",     icon: "G",   color: "#34a853" },
  { id: "bing",      label: "Bing",       icon: "B",   color: "#0078d4" },
  { id: "duckduckgo",label: "DuckDuckGo", icon: "🦆",  color: "#de5833" },
  { id: "youtube",   label: "YouTube",    icon: "▶",   color: "#ff0000" },
  { id: "wikipedia", label: "Wikipedia",  icon: "W",   color: "#aaa" },
  { id: "reddit",    label: "Reddit",     icon: "r/",  color: "#ff4500" },
];

const ENGINE_LINKS = {
  google:     q => `https://google.com/search?q=${encodeURIComponent(q)}`,
  bing:       q => `https://bing.com/search?q=${encodeURIComponent(q)}`,
  duckduckgo: q => `https://duckduckgo.com/?q=${encodeURIComponent(q)}`,
  youtube:    q => `https://youtube.com/results?search_query=${encodeURIComponent(q)}`,
  wikipedia:  q => `https://en.wikipedia.org/w/index.php?search=${encodeURIComponent(q)}`,
  reddit:     q => `https://reddit.com/search/?q=${encodeURIComponent(q)}`,
};

function SearchPanel() {
  const [query, setQuery] = useState("");
  const [activeEngine, setActiveEngine] = useState("all");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [history, setHistory] = useState([]);
  const inputRef = useRef(null);

  async function doSearch(q) {
    const term = (q || query).trim();
    if (!term) return;
    setLoading(true);
    setResults(null);
    if (!history.includes(term)) setHistory(h => [term, ...h.slice(0, 7)]);

    try {
      const engineNote = activeEngine !== "all"
        ? ` Focus your answer in the context of ${ENGINES.find(e=>e.id===activeEngine)?.label}.`
        : "";
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          tools: [{ type: "web_search_20250305", name: "web_search" }],
          system: `You are GO AI Search — an intelligent search assistant. When the user searches, use the web_search tool to find current results, then respond with:
1. A concise AI summary (2-3 sentences)
2. A JSON block at the end in this exact format (no markdown fences, just raw JSON after the text):
RESULTS_JSON:{"items":[{"title":"...","url":"...","snippet":"...","source":"..."},...],"total":N}

Always include 4-6 real results from your search. Keep snippets under 120 chars.${engineNote}`,
          messages: [{ role: "user", content: `Search: ${term}` }]
        })
      });
      const data = await response.json();
      const fullText = data.content?.filter(b => b.type === "text").map(b => b.text).join("") || "";

      let summary = fullText;
      let items = [];

      const jsonMarker = fullText.indexOf("RESULTS_JSON:");
      if (jsonMarker !== -1) {
        summary = fullText.slice(0, jsonMarker).trim();
        try {
          const jsonStr = fullText.slice(jsonMarker + 13).trim();
          const parsed = JSON.parse(jsonStr);
          items = parsed.items || [];
        } catch {}
      }

      setResults({ summary, items, query: term, engine: activeEngine });
    } catch (e) {
      setResults({ summary: "Search failed. Check connection.", items: [], query: term, engine: activeEngine });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflow: "hidden" }}>

      {/* Engine selector */}
      <div style={{
        padding: "10px 14px", borderBottom: "1px solid rgba(30,58,95,0.4)",
        display: "flex", gap: 6, overflowX: "auto", flexShrink: 0,
        scrollbarWidth: "none", background: "rgba(4,8,15,0.4)"
      }}>
        {ENGINES.map(e => (
          <button key={e.id} onClick={() => setActiveEngine(e.id)} style={{
            background: activeEngine === e.id ? `${e.color}20` : "rgba(15,23,42,0.6)",
            border: `1px solid ${activeEngine === e.id ? e.color + "66" : "rgba(30,58,95,0.5)"}`,
            borderRadius: 20, padding: "5px 13px", cursor: "pointer",
            color: activeEngine === e.id ? e.color : "#475569",
            fontFamily: "monospace", fontSize: 11, letterSpacing: 1,
            display: "flex", alignItems: "center", gap: 5, whiteSpace: "nowrap",
            transition: "all 0.2s", flexShrink: 0,
            boxShadow: activeEngine === e.id ? `0 0 10px ${e.color}22` : "none"
          }}>
            <span style={{ fontSize: e.id === "duckduckgo" ? 12 : 10 }}>{e.icon}</span>
            {e.label}
          </button>
        ))}
      </div>

      {/* Search input */}
      <div style={{ padding: "14px 14px 10px", flexShrink: 0 }}>
        <div style={{ display: "flex", gap: 8, position: "relative" }}>
          <div style={{ flex: 1, position: "relative" }}>
            <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "#334155", fontSize: 16 }}>⌕</span>
            <input
              ref={inputRef}
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={e => e.key === "Enter" && doSearch()}
              placeholder={`Search with GO AI${activeEngine !== "all" ? " · " + ENGINES.find(e2=>e2.id===activeEngine)?.label : ""}...`}
              style={{
                width: "100%", background: "rgba(15,23,42,0.9)",
                border: "1px solid rgba(30,58,95,0.8)", borderRadius: 10,
                padding: "12px 12px 12px 36px", color: "#e2e8f0",
                fontFamily: "'Inter', sans-serif", fontSize: 14, outline: "none",
                boxSizing: "border-box", transition: "border-color 0.2s"
              }}
            />
          </div>
          <button onClick={() => doSearch()} disabled={loading || !query.trim()} style={{
            background: "linear-gradient(135deg, #1d4ed8, #2563eb)",
            border: "none", borderRadius: 10, padding: "0 20px",
            color: "#fff", fontFamily: "monospace", fontSize: 12, letterSpacing: 1,
            cursor: loading ? "not-allowed" : "pointer", opacity: !query.trim() ? 0.4 : 1,
            transition: "all 0.2s", flexShrink: 0
          }}>
            {loading ? "..." : "SEARCH"}
          </button>
        </div>

        {/* History chips */}
        {history.length > 0 && !results && (
          <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
            {history.map((h, i) => (
              <button key={i} onClick={() => { setQuery(h); doSearch(h); }} style={{
                background: "rgba(30,58,95,0.3)", border: "1px solid rgba(30,58,95,0.5)",
                borderRadius: 12, padding: "3px 10px", color: "#475569",
                fontFamily: "monospace", fontSize: 10, cursor: "pointer", letterSpacing: 1
              }}>↺ {h}</button>
            ))}
          </div>
        )}
      </div>

      {/* Results */}
      <div style={{ flex: 1, overflowY: "auto", padding: "0 14px 14px", scrollbarWidth: "thin", scrollbarColor: "#1e3a5f #04080f" }}>

        {/* Loading */}
        {loading && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10, paddingTop: 10 }}>
            <div style={{ height: 60, borderRadius: 10, background: "rgba(30,58,95,0.15)", animation: "shimmer 1.5s infinite" }} />
            {[1,2,3,4].map(i => (
              <div key={i} style={{ borderRadius: 10, background: "rgba(15,23,42,0.6)", border: "1px solid rgba(30,58,95,0.3)", padding: 14 }}>
                <div style={{ height: 12, width: "60%", borderRadius: 6, background: "rgba(30,58,95,0.4)", marginBottom: 8, animation: "shimmer 1.5s infinite" }} />
                <div style={{ height: 9, width: "90%", borderRadius: 4, background: "rgba(30,58,95,0.25)", animation: "shimmer 1.5s infinite" }} />
              </div>
            ))}
          </div>
        )}

        {/* Empty state */}
        {!loading && !results && (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", gap: 14, paddingTop: 40 }}>
            <div style={{ fontSize: 48, opacity: 0.15 }}>⌕</div>
            <div style={{ color: "#1e3a5f", fontFamily: "monospace", fontSize: 12, letterSpacing: 2, textAlign: "center" }}>
              AI-POWERED SEARCH<br/>
              <span style={{ fontSize: 10, opacity: 0.6 }}>Searches the web in real-time</span>
            </div>
            {/* Quick searches */}
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", marginTop: 8 }}>
              {["Quantum computing", "AGI progress 2025", "Space exploration", "AI safety research"].map(s => (
                <button key={s} onClick={() => { setQuery(s); doSearch(s); }} style={{
                  background: "rgba(29,78,216,0.08)", border: "1px solid rgba(29,78,216,0.2)",
                  borderRadius: 20, padding: "6px 14px", color: "#3b82f6",
                  fontFamily: "monospace", fontSize: 11, cursor: "pointer", letterSpacing: 1
                }}>{s}</button>
              ))}
            </div>
          </div>
        )}

        {/* Results */}
        {!loading && results && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10, paddingTop: 4 }}>

            {/* AI Summary */}
            <div style={{
              background: "rgba(29,78,216,0.08)", border: "1px solid rgba(59,130,246,0.25)",
              borderRadius: 12, padding: "14px 16px"
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 8 }}>
                <div style={{ width: 20, height: 20, borderRadius: 6, background: "rgba(59,130,246,0.2)", border: "1px solid rgba(59,130,246,0.4)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, color: "#60a5fa" }}>AI</div>
                <span style={{ color: "#60a5fa", fontFamily: "monospace", fontSize: 10, letterSpacing: 2 }}>GO AI SUMMARY</span>
              </div>
              <p style={{ color: "#94a3b8", fontFamily: "'Inter', sans-serif", fontSize: 13, lineHeight: 1.7, margin: 0 }}>
                {results.summary || "Search complete."}
              </p>
            </div>

            {/* Engine links row */}
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {Object.entries(ENGINE_LINKS).map(([id, fn]) => {
                const eng = ENGINES.find(e => e.id === id);
                return (
                  <a key={id} href={fn(results.query)} target="_blank" rel="noopener noreferrer" style={{
                    background: `${eng.color}10`,
                    border: `1px solid ${eng.color}30`,
                    borderRadius: 8, padding: "4px 10px",
                    color: eng.color, fontFamily: "monospace", fontSize: 10,
                    textDecoration: "none", letterSpacing: 1,
                    display: "flex", alignItems: "center", gap: 4,
                    transition: "all 0.2s"
                  }}>
                    <span>{eng.icon}</span> {eng.label} ↗
                  </a>
                );
              })}
            </div>

            {/* Result cards */}
            {results.items.length > 0 ? results.items.map((item, i) => (
              <a key={i} href={item.url} target="_blank" rel="noopener noreferrer" style={{
                background: "rgba(15,23,42,0.7)", border: "1px solid rgba(30,58,95,0.5)",
                borderRadius: 12, padding: "14px 16px", textDecoration: "none",
                display: "block", transition: "all 0.2s"
              }}>
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 10, marginBottom: 5 }}>
                  <div style={{ color: "#e2e8f0", fontFamily: "'Inter', sans-serif", fontSize: 13, fontWeight: 500, lineHeight: 1.4 }}>{item.title}</div>
                  <span style={{ color: "#1e3a5f", fontSize: 12, flexShrink: 0 }}>↗</span>
                </div>
                <div style={{ color: "#475569", fontFamily: "monospace", fontSize: 10, marginBottom: 6, letterSpacing: 1 }}>{item.source || item.url?.slice(0,50)}</div>
                <div style={{ color: "#64748b", fontFamily: "'Inter', sans-serif", fontSize: 12, lineHeight: 1.5 }}>{item.snippet}</div>
              </a>
            )) : (
              <div style={{ color: "#334155", fontFamily: "monospace", fontSize: 11, textAlign: "center", padding: 20 }}>
                Open any engine above to see full results ↗
              </div>
            )}

            {/* New search */}
            <button onClick={() => { setResults(null); setQuery(""); setTimeout(() => inputRef.current?.focus(), 100); }} style={{
              background: "transparent", border: "1px solid rgba(30,58,95,0.4)",
              borderRadius: 8, padding: "8px", color: "#334155",
              fontFamily: "monospace", fontSize: 11, cursor: "pointer", letterSpacing: 1
            }}>← NEW SEARCH</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ===================== GO AI ENGINE PANEL =====================
const ENGINE_LOG_TEMPLATES = [
  { tag: "OK",  color: "#00ffcc", msgs: ["Quantum entanglement stabilized at {n}%.", "Alpha channel sync verified.", "Qbit coherence at {n}%."] },
  { tag: "WRN", color: "#ffcc00", msgs: ["Classic Engine heat approaching {n}°C.", "Beta flux variance: {n}%.", "RAM 02 usage exceeding threshold."] },
  { tag: "SYS", color: "#a78bfa", msgs: ["Quantum bridge handshake complete.", "Classic core rebalancing...", "Engine sync protocol activated."] },
  { tag: "INF", color: "#60a5fa", msgs: ["System check initiated...", "Optimizer standing by.", "Uplink stable at {n} PB/s."] },
];
function randomEngineLog() {
  const g = ENGINE_LOG_TEMPLATES[Math.floor(Math.random() * ENGINE_LOG_TEMPLATES.length)];
  const msg = g.msgs[Math.floor(Math.random() * g.msgs.length)].replace("{n}", (Math.random()*40+60).toFixed(1));
  const now = new Date();
  return { time: `${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}:${String(now.getSeconds()).padStart(2,"0")}.${String(now.getMilliseconds()).slice(0,2).padStart(2,"0")}`, tag: g.tag, color: g.color, msg, id: Math.random() };
}

function VBar({ value, color, label }) {
  const h = 180;
  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:6 }}>
      <div style={{ width:40, height:h, borderRadius:20, background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", position:"relative", overflow:"hidden" }}>
        <div style={{ position:"absolute", bottom:0, left:0, right:0, height:`${value}%`, background:`linear-gradient(to top,${color},${color}99)`, borderRadius:20, boxShadow:`0 0 18px ${color}aa`, transition:"height 1.2s ease" }} />
        <div style={{ position:"absolute", top:8, left:"30%", width:"20%", bottom:8, background:"rgba(255,255,255,0.05)", borderRadius:8 }} />
      </div>
      <div style={{ fontFamily:"monospace", fontSize:9, color, letterSpacing:2, writingMode:"vertical-rl", transform:"rotate(180deg)", marginTop:-h-10, marginBottom:h+10, textShadow:`0 0 8px ${color}` }}>{label}</div>
    </div>
  );
}

function EnginePanel() {
  const [alpha, setAlpha] = useState(88);
  const [beta, setBeta] = useState(62);
  const [qbits, setQbits] = useState(65.2);
  const [cpu, setCpu] = useState(84);
  const [throughput, setThroughput] = useState(1.42);
  const [latency, setLatency] = useState(0.02);
  const [optimizing, setOptimizing] = useState(false);
  const [optPct, setOptPct] = useState(0);
  const [logs, setLogs] = useState([
    { time:"14:21:58.45", tag:"WRN", color:"#ffcc00", msg:"Classic Engine heat levels approaching 72°C.", id:1 },
    { time:"14:21:55.21", tag:"OK",  color:"#00ffcc", msg:"Quantum entanglement stabilized at 98.4%.", id:2 },
    { time:"14:21:52.09", tag:"SYS", color:"#a78bfa", msg:"Initiating boot sequence: Super Engine 2.", id:3 },
    { time:"14:21:50.00", tag:"INF", color:"#60a5fa", msg:"System check initiated...", id:4 },
  ]);

  useEffect(() => {
    const iv = setInterval(() => {
      setAlpha(v => Math.min(100,Math.max(20,v+(Math.random()-0.48)*6)));
      setBeta(v  => Math.min(100,Math.max(20,v+(Math.random()-0.48)*8)));
      setQbits(v => parseFloat((Math.min(99,Math.max(40,v+(Math.random()-0.5)*2))).toFixed(1)));
      setCpu(v   => Math.min(99,Math.max(40,v+Math.floor((Math.random()-0.48)*5))));
      setThroughput(v => parseFloat((Math.max(0.1,v+(Math.random()-0.5)*0.2)).toFixed(2)));
      setLatency(v    => parseFloat((Math.max(0.01,v+(Math.random()-0.5)*0.01)).toFixed(2)));
      setLogs(l => [randomEngineLog(), ...l.slice(0,10)]);
    }, 2500);
    return () => clearInterval(iv);
  }, []);

  function handleOptimize() {
    if (optimizing) return;
    setOptimizing(true); setOptPct(0);
    let p = 0;
    const iv = setInterval(() => {
      p += Math.random()*12+4; setOptPct(Math.min(100,p));
      if (p >= 100) {
        clearInterval(iv); setOptimizing(false); setOptPct(0);
        setAlpha(92); setBeta(88); setQbits(98.4); setCpu(41);
        setLogs(l => [{ time:new Date().toTimeString().slice(0,8)+".00", tag:"OK", color:"#00ffcc", msg:"Optimization complete. All engines nominal.", id:Math.random() }, ...l.slice(0,10)]);
      }
    }, 120);
  }

  return (
    <div style={{ height:"100%", overflowY:"auto", padding:"18px 16px", display:"flex", flexDirection:"column", gap:16, scrollbarWidth:"thin", scrollbarColor:"#1e3a5f #04080f" }}>
      <style>{`@keyframes pulse2{0%,100%{box-shadow:0 0 20px #00ffcc44}50%{box-shadow:0 0 40px #00ffccaa,0 0 60px #00ffcc22}} @keyframes logSlide{0%{opacity:0;transform:translateY(-6px)}100%{opacity:1;transform:translateY(0)}}`}</style>

      {/* Header */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
        <div>
          <div style={{ fontFamily:"monospace", fontWeight:700, fontSize:22, color:"#00ffcc", letterSpacing:3, textShadow:"0 0 20px #00ffcc66" }}>GO AI ENGINE</div>
          <div style={{ color:"#334155", fontSize:10, letterSpacing:3, marginTop:2 }}>SYSTEM MONITOR V2.0.4</div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:6, background:"rgba(0,255,204,0.05)", border:"1px solid rgba(0,255,204,0.2)", borderRadius:20, padding:"6px 14px" }}>
          <div style={{ width:6, height:6, borderRadius:"50%", background:"#00ffcc", boxShadow:"0 0 8px #00ffcc", animation:"blink 2s infinite" }} />
          <span style={{ color:"#00ffcc", fontSize:11, letterSpacing:2 }}>ONLINE</span>
        </div>
      </div>

      {/* Engine display */}
      <div style={{ background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.06)", borderRadius:16, padding:"18px 14px 26px", display:"flex", alignItems:"stretch", gap:10, position:"relative" }}>
        <div style={{ position:"absolute", top:-12, right:20, background:"#04080f", border:"1px solid rgba(255,255,255,0.1)", borderRadius:8, padding:"2px 10px", fontFamily:"monospace", fontSize:9, color:"#555", letterSpacing:1 }}>RAM 01</div>

        {/* Quantum */}
        <div style={{ background:"rgba(0,255,204,0.03)", border:"1px solid rgba(0,255,204,0.1)", borderRadius:12, padding:"12px 12px 18px", flex:1, minWidth:0, position:"relative" }}>
          <div style={{ position:"absolute", left:6, top:"50%", transform:"translateY(-50%) rotate(-90deg)", fontSize:7, color:"#333", letterSpacing:3, whiteSpace:"nowrap" }}>SUPER ENGINE 2</div>
          <div style={{ marginLeft:8 }}>
            <div style={{ width:28, height:28, background:"rgba(0,255,204,0.12)", border:"1px solid rgba(0,255,204,0.3)", borderRadius:6, marginBottom:8, boxShadow:"0 0 10px rgba(0,255,204,0.15)" }} />
            <div style={{ color:"#eee", fontSize:12, fontWeight:700, letterSpacing:2, marginBottom:8 }}>QUANTUM</div>
            <div style={{ height:4, borderRadius:2, background:"rgba(255,255,255,0.06)", overflow:"hidden", marginBottom:5 }}>
              <div style={{ height:"100%", width:`${qbits}%`, borderRadius:2, background:"#00ffcc", boxShadow:"0 0 8px #00ffcc88", transition:"width 1.2s ease" }} />
            </div>
            <div style={{ color:"#00ffcc", fontSize:10, letterSpacing:1 }}>{qbits} Qbits</div>
          </div>
        </div>

        {/* Bars */}
        <div style={{ display:"flex", gap:8, alignItems:"flex-end", padding:"0 4px" }}>
          <VBar value={alpha} color="#00ffcc" label="ALPHA" />
          <VBar value={beta}  color="#8b5cf6" label="BETA"  />
        </div>

        {/* Classic */}
        <div style={{ background:"rgba(139,92,246,0.03)", border:"1px solid rgba(139,92,246,0.12)", borderRadius:12, padding:"12px 12px 18px", flex:1, minWidth:0, position:"relative", display:"flex", flexDirection:"column", justifyContent:"flex-end" }}>
          <div style={{ position:"absolute", right:6, top:"50%", transform:"translateY(-50%) rotate(90deg)", fontSize:7, color:"#333", letterSpacing:3, whiteSpace:"nowrap" }}>SUPER ENGINE 1</div>
          <div style={{ marginRight:6 }}>
            <div style={{ fontSize:20, marginBottom:6, color:"#8b5cf6", filter:"drop-shadow(0 0 6px #8b5cf688)" }}>⬡</div>
            <div style={{ color:"#eee", fontSize:12, fontWeight:700, letterSpacing:2, marginBottom:8 }}>CLASSIC</div>
            <div style={{ height:4, borderRadius:2, background:"rgba(255,255,255,0.06)", overflow:"hidden", marginBottom:5 }}>
              <div style={{ height:"100%", width:`${cpu}%`, borderRadius:2, background:"#8b5cf6", boxShadow:"0 0 8px #8b5cf688", transition:"width 1.2s ease" }} />
            </div>
            <div style={{ color:"#8b5cf6", fontSize:10, letterSpacing:1 }}>CPU {cpu}%</div>
          </div>
        </div>

        <div style={{ position:"absolute", bottom:-12, left:20, background:"#04080f", border:"1px solid rgba(255,255,255,0.1)", borderRadius:8, padding:"2px 10px", fontFamily:"monospace", fontSize:9, color:"#555", letterSpacing:1 }}>RAM 02</div>
      </div>

      {/* Logs */}
      <div style={{ background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.06)", borderRadius:14, overflow:"hidden" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 14px", borderBottom:"1px solid rgba(255,255,255,0.05)" }}>
          <span style={{ color:"#00ffcc", fontSize:11, fontWeight:700, letterSpacing:2, fontFamily:"monospace" }}>LIVE SYSTEM LOGS</span>
          <div style={{ display:"flex", gap:6 }}>
            {["CLEAR","EXPORT"].map(b => (
              <button key={b} onClick={() => b==="CLEAR" && setLogs([])} style={{ background:"transparent", border:`1px solid ${b==="EXPORT"?"rgba(0,255,204,0.35)":"rgba(255,255,255,0.1)"}`, borderRadius:6, padding:"3px 10px", color:b==="EXPORT"?"#00ffcc":"#555", fontFamily:"monospace", fontSize:9, cursor:"pointer", letterSpacing:1 }}>{b}</button>
            ))}
          </div>
        </div>
        <div style={{ padding:"8px 12px", maxHeight:160, overflowY:"auto", display:"flex", flexDirection:"column", gap:2, scrollbarWidth:"thin" }}>
          {logs.length === 0 && <div style={{ color:"#333", fontSize:11, textAlign:"center", padding:12, fontFamily:"monospace" }}>Log cleared.</div>}
          {logs.map((l,i) => (
            <div key={l.id} style={{ display:"grid", gridTemplateColumns:"88px 42px 1fr", gap:7, fontSize:10, lineHeight:1.6, animation: i===0?"logSlide 0.3s ease":"none" }}>
              <span style={{ color:"#334155", fontFamily:"monospace" }}>{l.time}</span>
              <span style={{ color:l.color, fontWeight:700, fontFamily:"monospace" }}>[{l.tag}]</span>
              <span style={{ color:"#64748b", fontFamily:"monospace" }}>{l.msg}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Metrics */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
        {[{label:"THROUGHPUT",value:throughput.toFixed(2),unit:"PB/s"},{label:"LATENCY",value:latency.toFixed(2),unit:"ms"}].map(m => (
          <div key={m.label} style={{ background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.06)", borderRadius:12, padding:"14px 16px" }}>
            <div style={{ color:"#334155", fontSize:9, letterSpacing:2, marginBottom:8, fontFamily:"monospace" }}>{m.label}</div>
            <div style={{ display:"flex", alignItems:"baseline", gap:5 }}>
              <span style={{ color:"#e2e8f0", fontFamily:"monospace", fontSize:24, fontWeight:700 }}>{m.value}</span>
              <span style={{ color:"#334155", fontSize:11, fontFamily:"monospace" }}>{m.unit}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Optimize */}
      <button onClick={handleOptimize} disabled={optimizing} style={{ position:"relative", overflow:"hidden", background:optimizing?"rgba(0,255,204,0.1)":"linear-gradient(135deg,#00ffcc,#00e6b8)", border:optimizing?"1px solid rgba(0,255,204,0.35)":"none", borderRadius:14, padding:"18px", color:optimizing?"#00ffcc":"#04080f", fontFamily:"monospace", fontWeight:700, fontSize:14, letterSpacing:3, cursor:optimizing?"not-allowed":"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:8, animation:optimizing?"none":"pulse2 2.5s infinite", transition:"all 0.3s" }}>
        {optimizing && <div style={{ position:"absolute", left:0, top:0, bottom:0, width:`${optPct}%`, background:"rgba(0,255,204,0.15)", transition:"width 0.1s linear" }} />}
        <span style={{ position:"relative" }}>▮</span>
        <span style={{ position:"relative" }}>{optimizing?`OPTIMIZING... ${Math.floor(optPct)}%`:"OPTIMIZE ENGINES"}</span>
      </button>
    </div>
  );
}

function Workspace() {
  const [active, setActive] = useState("chat");
  const [time, setTime] = useState(new Date());
  const [entered, setEntered] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setEntered(true), 50);
    const iv = setInterval(() => setTime(new Date()), 1000);
    return () => { clearTimeout(t); clearInterval(iv); };
  }, []);

  return (
    <div style={{
      position: "fixed", inset: 0, background: "#04080f",
      display: "flex", flexDirection: "column",
      opacity: entered ? 1 : 0, transition: "opacity 0.6s ease",
      fontFamily: "'Inter', sans-serif"
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=Inter:wght@300;400;500;600&display=swap');
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
        @keyframes shimmer { 0%{opacity:0.4} 50%{opacity:0.8} 100%{opacity:0.4} }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(30,58,95,0.8); border-radius: 4px; }
        input::placeholder, textarea::placeholder { color: #334155; }
      `}</style>

      {/* Grid bg */}
      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none",
        backgroundImage: "linear-gradient(rgba(29,78,160,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(29,78,160,0.04) 1px, transparent 1px)",
        backgroundSize: "48px 48px"
      }} />
      <div style={{ position: "fixed", top: -200, left: -200, width: 500, height: 500, background: "radial-gradient(circle, rgba(29,78,160,0.12) 0%, transparent 70%)", pointerEvents: "none" }} />

      {/* Header */}
      <header style={{
        padding: "0 20px", height: 52, borderBottom: "1px solid rgba(30,58,95,0.6)",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        background: "rgba(4,8,15,0.95)", backdropFilter: "blur(12px)",
        position: "relative", zIndex: 10, flexShrink: 0
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#3b82f6", boxShadow: "0 0 10px #3b82f6", animation: "blink 2.5s infinite" }} />
          <span style={{ fontFamily: "'Orbitron', monospace", fontWeight: 900, fontSize: 14, color: "#e2e8f0", letterSpacing: 4 }}>GO AI</span>
          <span style={{ color: "#334155", fontSize: 10, letterSpacing: 1 }}>WORKSPACE</span>
        </div>

        <nav style={{ display: "flex", gap: 2 }}>
          {MODULES.map(m => (
            <button key={m.id} onClick={() => setActive(m.id)} style={{
              background: active === m.id ? "rgba(29,78,216,0.2)" : "transparent",
              border: `1px solid ${active === m.id ? "rgba(59,130,246,0.45)" : "transparent"}`,
              borderRadius: 6, color: active === m.id ? "#60a5fa" : "#475569",
              fontFamily: "monospace", fontSize: 11, padding: "6px 14px",
              cursor: "pointer", letterSpacing: 1, transition: "all 0.15s",
              display: "flex", alignItems: "center", gap: 6
            }}>
              <span>{m.icon}</span>{m.label}
            </button>
          ))}
        </nav>

        <div style={{ display: "flex", alignItems: "center", gap: 14, fontSize: 10, color: "#334155", fontFamily: "monospace", letterSpacing: 1 }}>
          <span style={{ color: "#1d4ed8" }}>● ONLINE</span>
          <span>{time.toLocaleTimeString("en-US", { hour12: false })}</span>
        </div>
      </header>

      {/* Content */}
      <main style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column", position: "relative", zIndex: 1 }}>
        <div style={{ padding: "6px 16px", borderBottom: "1px solid rgba(30,58,95,0.4)", color: "#334155", fontSize: 10, fontFamily: "monospace", letterSpacing: 2, flexShrink: 0, background: "rgba(4,8,15,0.5)" }}>
          {{ chat: "◈ AI CHAT — CLAUDE POWERED", search: "⌕ AI SEARCH — GOOGLE · BING · YOUTUBE · WIKI · REDDIT · DUCKDUCKGO", engine: "⬡ GO AI ENGINE — SYSTEM MONITOR V2.0.4", dashboard: "◉ LIVE DASHBOARD", tools: "◎ DEVELOPER TOOLS" }[active]}
        </div>
        <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column" }}>
          {active === "chat"      && <ChatPanel />}
          {active === "search"    && <SearchPanel />}
          {active === "engine"    && <EnginePanel />}
          {active === "dashboard" && <div style={{ height: "100%", overflowY: "auto" }}><DashboardPanel /></div>}
          {active === "tools"     && <div style={{ height: "100%", overflowY: "auto" }}><ToolsPanel /></div>}
        </div>
      </main>

      <footer style={{
        height: 28, padding: "0 20px", borderTop: "1px solid rgba(30,58,95,0.4)",
        display: "flex", justifyContent: "space-between", alignItems: "center",
        background: "rgba(4,8,15,0.95)", fontSize: 9, color: "#1e3a5f",
        fontFamily: "monospace", letterSpacing: 1, flexShrink: 0, zIndex: 10
      }}>
        <span>CLASSICAL + QUANTUM AI</span>
        <span>CLAUDE SONNET 4 · ANTHROPIC</span>
        <span>STATUS: NOMINAL</span>
      </footer>
    </div>
  );
}

// ===================== ROOT =====================
export default function App() {
  const [started, setStarted] = useState(false);
  return started ? <Workspace /> : <SplashScreen onStart={() => setStarted(true)} />;
}
